<?php
$_SERVER['ENVIRONMENT'] = 'experts';

require_once('../CI/index.php');