<?php
$_SERVER['ENVIRONMENT'] = 'speakers';

require_once('../CI/index.php');